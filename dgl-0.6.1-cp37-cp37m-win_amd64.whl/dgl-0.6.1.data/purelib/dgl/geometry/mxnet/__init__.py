"""Package for mxnet-specific Geometry modules."""
from .fps import *
from .edge_coarsening import *
