"""Package for DGL's internal IR."""
from .executor import *
from .program import get_current_prog, prog
